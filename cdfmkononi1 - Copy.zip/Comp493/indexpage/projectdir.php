<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PROJECTS</title>
    
</head>
<header>
    <h1>Hi, Welcome to our Projects Workforce</h1>
    
</header>
<body>
    <h1>Our Projects Workforce are either labour based or contract based </h1>  
        <a href="contract.php"> OUR PROJECTS</a>
</body>
</html>




<style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            background-color: antiquewhite;
        }
        header {
            background-color: #4CAF50;
            color: white;
            padding: 30px;
            text-align: center;
            width: 100%;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        header h1 {
            margin: 0;
        }
        a {
            display: inline-block;
            margin: 20px 30px;
            padding: 20px 30px;
            color: white;
            background-color: #008CBA;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        a:hover {
            background-color: #005f75;
        }
    </style>